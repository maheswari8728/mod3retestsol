package com.cg.entities;

import java.io.Serializable;

import org.hibernate.annotations.Entity;
import org.hibernate.annotations.Table;


@Entity
@Table(appliesTo = "Ass_bean")

public class AssessmentBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private int details_id;
	private String trainee_name;
	private String module_name;
	private double mpt_score;
	private double mtt_score;
	private double ass_marks;
	private double total;
	
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public String getTrainee_name() {
		return trainee_name;
	}
	public void setTrainee_name(String trainee_name) {
		this.trainee_name = trainee_name;
	}
	public String getModule_name() {
		return module_name;
	}
	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}
	public double getMpt_score() {
		return mpt_score;
	}
	public void setMpt_score(double mpt_score) {
		this.mpt_score = mpt_score;
	}
	public double getMtt_score() {
		return mtt_score;
	}
	public void setMtt_score(double mtt_score) {
		this.mtt_score = mtt_score;
	}
	public double getAss_marks() {
		return ass_marks;
	}
	public void setAss_marks(double ass_marks) {
		this.ass_marks = ass_marks;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "AssessmentBean [trainee_name=" + trainee_name + ", module_name=" + module_name + ", mpt_score="
				+ mpt_score + ", mtt_score=" + mtt_score + ", ass_marks=" + ass_marks + ", total=" + total + "]";
	}
	

}
