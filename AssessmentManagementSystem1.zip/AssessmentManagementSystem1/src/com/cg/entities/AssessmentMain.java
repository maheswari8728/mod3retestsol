package com.cg.entities;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AssessmentMain {
	
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		AssessmentBean bean=new AssessmentBean();
		
		System.out.println("enter Trainee Name");
		String traineename=sc.next();
		bean.setTrainee_name(traineename);

		System.out.println("enter Module Name");
		String modulename=sc.next();
		bean.setModule_name(modulename);
		
		System.out.println("enter Trainee Mpt Score");
		double mptscore=sc.nextDouble();
		bean.setMpt_score(mptscore);
		
		System.out.println("enter Trainee  Mtt Score");
		double mttscore=sc.nextDouble();
		bean.setMtt_score(mttscore);
		
		System.out.println("enter Assignment Marks");
		double asmarks=sc.nextDouble();
		bean.setAss_marks(asmarks);
		
		double total=mttscore+mptscore;
		System.out.println("total score is:"+total);
		bean.setTotal(total);
		
		em.persist(bean);
		
		
		System.out.println("details are added");
		
		
		em.getTransaction().commit();
		em.close();
		factory.close();
		
		}
	}


