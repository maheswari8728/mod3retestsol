package com.cg.service;

import com.cg.bean.LoginBean;

public class LoginServiceImpl implements ILoginService{

	@Override
	public boolean verifyLogin(LoginBean bean) {
		
	
		boolean result = false;
		if (bean.getUserName() =="admin"
				&& bean.getPassword()=="admin") {
			result = true;

		}
		return result;

	}
}
