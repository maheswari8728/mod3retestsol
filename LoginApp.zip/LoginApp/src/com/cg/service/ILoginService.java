package com.cg.service;

import com.cg.bean.LoginBean;

public interface ILoginService {
	
	public boolean verifyLogin(LoginBean bean);
	

}
