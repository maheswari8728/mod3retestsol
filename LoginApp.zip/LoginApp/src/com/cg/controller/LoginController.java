package com.cg.controller;

import java.io.IOException;

import javax.security.auth.login.LoginException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.LoginBean;
import com.cg.exception.ExceptionMessages;
import com.cg.service.ILoginService;
import com.cg.service.LoginServiceImpl;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
     public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String username = request.getParameter("username").trim();
		String password = request.getParameter("password").trim();
		ILoginService service = new LoginServiceImpl();
		LoginBean bean = new LoginBean();
		bean.setUserName(username);
		bean.setPassword(password);
		
		try {
		
		if(service.verifyLogin(bean)) {
			
			HttpSession httpSession=request.getSession();
			httpSession.setAttribute("username", username);
			request.getRequestDispatcher("/success.jsp")
			.include(request, response);
			
		} else {
			request.setAttribute("errmsg",
					"Invalid Username and Password! Try Again!!");
			request.getRequestDispatcher("error.jsp")
					.include(request, response);
		}
			
		} catch (Exception e) {
			request.setAttribute("errmsg", e);
			request.getRequestDispatcher("error.jsp").include(request,
					response);
		}
	
	}
			
		
	}


